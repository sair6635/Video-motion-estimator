# Design-of-Video-Motion-Estimator-
Verilog code of Video motion Estimator 

The Video motion Estimator is used for various Video  Compression Technologies and Image Search Technologies. Our Video motion estimator contains
16 by 16 reference frame and 31 * 31 Search Frame. 
